#include"myMysql.h"




void createTable(char* srcName, char* destName){
    csvToBin(srcName, destName);
}