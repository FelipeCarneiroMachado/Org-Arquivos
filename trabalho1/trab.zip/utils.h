#ifndef UTILS_H
    #define UTILS_H
    #include<stdbool.h>
    #include<stdlib.h>
    #include<string.h>
    #include<stdio.h>
    #include<stdint.h>
    #include<ctype.h>
    void scan_quote_string(char *str);
    void binarioNaTela(char *nomeArquivoBinario);
    void slice(char * dest, char* src, int start, int end);



#endif