Arquivo zip gerado em: 09/06/2024 10:53:38 
Este arquivo contém os casos de teste cadastrados até o momento, disponibilizado pelo professor aos alunos.
Exercício: Trabalho Introdutório