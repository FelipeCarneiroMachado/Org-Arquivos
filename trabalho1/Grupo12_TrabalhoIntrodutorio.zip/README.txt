Trabalho prático introdutório da dsiciplina SCC0215 - Organização de Arquivos
ICMC-USP, Primeiro semestre de 2024
Link do video: https://drive.google.com/file/d/1G40-3ix879ICT-oErW8Zs52jxyukylWs/view?usp=drive_link
Realizado pela dupla(Grupo 12):
    Felipe Carneiro Machado - NUSP: 14569373
    Matheus Araujo Pinheiro - NUSP: 14676810