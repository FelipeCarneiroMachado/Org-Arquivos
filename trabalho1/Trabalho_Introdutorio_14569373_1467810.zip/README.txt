Trabalho prático introdutório da dsiciplina SCC0215 - Organização de Arquivos
ICMC-USP, Primeiro semestre de 2024
Realizado pela dupla:
    Felipe Carneiro Machado - NUSP: 14569373
    Matheus Araujo Pinheiro - NUSP: 1467810